const express = require('express');
const stripe = require('stripe')(// Stripe Secret Key) Remove kra danat); // Replace with your Secret Key
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const corsOptions = {
    origin: "*",  // 🔹 Later, change this to "https://ou-hostel-management-system.web.app"
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    credentials: true
};
app.use(cors(corsOptions));

app.use(bodyParser.json());

// Create Payment Session
app.post('/create-payment-session', async (req, res) => {
    const { amount, studentId } = req.body;

    try {
        // Ensure the amount is at least 160 LKR (equivalent to $0.50)
        if (amount < 160) {
            return res.status(400).json({ error: 'Amount must be at least 160 LKR.' });
        }

        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            mode: 'payment',
            line_items: [
                {
                    price_data: {
                        currency: 'lkr',
                        product_data: { name: 'Hostel Room Payment' },
                        unit_amount: amount * 100, // Convert amount to cents
                    },
                    quantity: 1,
                },
            ],
            metadata: { studentId }, // Attach student ID for tracking
            success_url: 'https://ou-hostel-management-system.web.app/payment-success.html',
            cancel_url: 'https://ou-hostel-management-system.web.app/payment-cancel.html',

        });

        res.json({ url: session.url });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


const PORT = 3000;
app.listen(PORT, () => console.log(`Stripe backend running on port ${PORT}`));
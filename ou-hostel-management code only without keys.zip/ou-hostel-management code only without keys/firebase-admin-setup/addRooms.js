const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

const floors = [
  { prefix: "G", floor: 1, genderRestriction: "girls" },  // 1st Floor (Girls)
  { prefix: "F", floor: 2, genderRestriction: "girls" },  // 2nd Floor (Girls)
  { prefix: "S", floor: 3, genderRestriction: "boys" },   // 3rd Floor (Boys)
  { prefix: "T", floor: 4, genderRestriction: "boys" }    // 4th Floor (Boys)
];

const maxOccupants = 4;  // Max students per room

async function addRooms() {
  for (const { prefix, floor, genderRestriction } of floors) {
    for (let i = 1; i <= 27; i++) {
      const roomNumber = `${prefix}${i}`;
      const roomData = {
        floor: floor,
        roomNumber: roomNumber,
        genderRestriction: genderRestriction,
        occupants: [],
        maxOccupants: maxOccupants,
        status: "available",
        logNotes: "",
        availabilityDate: null
      };

      try {
        await db.collection('Rooms').doc(roomNumber).set(roomData);
        console.log(`Room ${roomNumber} added.`);
      } catch (error) {
        console.error(`Error adding room ${roomNumber}:`, error);
      }
    }
  }
}

addRooms().then(() => {
  console.log("All rooms added successfully.");
  process.exit(0);
}).catch((error) => {
  console.error("Error adding rooms:", error);
  process.exit(1);
});

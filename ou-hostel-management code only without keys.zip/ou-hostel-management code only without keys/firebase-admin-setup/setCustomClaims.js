// setCustomClaims.js

const admin = require('firebase-admin');

// Load the service account key JSON file
const serviceAccount = require('./serviceAccountKey.json');

// Initialize the Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

// Function to assign roles
async function setCustomUserClaims(uid, role) {
    try {
      // Set the custom claim for the specified user
      await admin.auth().setCustomUserClaims(uid, { role });
      console.log(`Custom claims set for UID ${uid}:`, { role });
    } catch (error) {
      console.error("Error setting custom claims:", error);
    }
  }
  
  // Example usage
  const adminUID = "PochImhvINPXmNmxCjkWeb4S0EZ2";  // Replace with the actual UID for an admin user
  const wardenUID = "OqFQtWAi65MVBgGHECeyQ51EFJS2";  // Replace with the actual UID for a warden user
  
  setCustomUserClaims(adminUID, "Admin");
  setCustomUserClaims(wardenUID, "Warden");
  